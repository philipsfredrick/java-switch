package com.danielkpobari.formvalidationapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormValidationAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
