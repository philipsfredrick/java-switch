package com.interswitch.contact.model;

public class Referee {
    private String name;
    private String profession;
    private String phoneNumber;
    private int addressId;
}
