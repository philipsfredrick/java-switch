package com.interswitch.contact.model;

import java.util.Date;

public class Contact {
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String sex;
    private Date dateOfBirth;
}
