package com.interswitch.assignment.inheritance;

public class TransportFare {
    public static void main(String[] args) {
        Bus bus = new Bus(50);
        System.out.println(bus.fare());
    }
}
